# local_accessibility 3.0.2

Panel de accesibilidad para Moodle 4.5–5.x basado en widgets administrables.

## Cambios de la versión 3.0.2

- Corrige el lanzador que podía quedar sin listener cuando el módulo AMD se inicializaba antes de que el tema terminara de insertar el pie de página.
- El modal se mueve a `document.body` únicamente al abrirse, no durante la composición inicial del DOM.
- La inicialización se reintenta tras `DOMContentLoaded`, en el siguiente ciclo del navegador y mediante un `MutationObserver` que se desconecta en cuanto encuentra el panel.
- Mantiene el aislamiento con `inert`, el *focus trap*, el retorno del foco y el diseño compacto de dos columnas.

## Cambios de la versión 3.0.1

- Corrige el bloqueo de todos los controles al abrir el panel: el contenedor del diálogo ya no queda marcado como `inert` por los wrappers del tema.
- Mueve el modal a `document.body` para mantener correctamente el aislamiento, la gestión del foco y la interacción en distintos temas de Moodle.
- Reduce el desplazamiento vertical mediante una cuadrícula de dos columnas en escritorio, tarjetas más compactas y controles de menor altura.
- Mantiene una sola columna y controles adaptados en pantallas pequeñas.

## Características

- Diálogo modal ARIA con nombre y descripción accesibles, cierre con `Escape`, fondo inerte, *focus trap* y devolución del foco al activador.
- Preferencias persistidas en la base de datos por usuario autenticado y en la sesión del servidor para invitados.
- Sincronización entre dispositivos para usuarios autenticados.
- `localStorage` se usa únicamente como caché optimista; el estado del servidor sustituye la caché en cada carga.
- Aplicación inicial desde PHP mediante clases de `body` y CSS bloqueante servido en cabecera para reducir el FOUC.
- Panel y controles traducibles mediante `get_string()`; se incluyen inglés y español en todos los componentes.
- Gestión dinámica de widgets: el panel se construye recorriendo `local_accessibility_getwidgetinstances()` y respeta activación, desactivación y orden administrativos.
- Servicio AJAX validado, peticiones serializadas por widget y acción «Reiniciar todo» mediante POST con `sesskey`.
- Incluye color de fondo y texto, tipo y tamaño de letra, kerning, visibilidad de imágenes, espaciado entre caracteres, interlineado, alineación, resaltado de enlaces, ancho de párrafo y alto contraste.
- Implementa el proveedor de privacidad de Moodle para exportar y eliminar las preferencias guardadas.

## Compatibilidad

- Versión mínima: Moodle 4.5 (`$plugin->requires = 2024100700`).
- Rango declarado: ramas 4.5 a 5.x (`$plugin->supported = [405, 599]`).
- Usa la Hooks API disponible en las versiones objetivo y módulos AMD compilados.

## Instalación y actualización

1. Haga una copia de seguridad de la base de datos y de la versión anterior del plugin.
2. Instale el ZIP desde el instalador de extensiones de Moodle o descomprima la carpeta `accessibility` en:
   - Moodle 4.5 y 5.0: `local/accessibility`.
   - Moodle 5.1 y posteriores con la nueva raíz pública: `public/local/accessibility`.
3. Complete la actualización desde **Administración del sitio > Notificaciones**.
4. Purgue las cachés de Moodle después de actualizar.
5. Gestione el orden y la activación de herramientas desde **Administración del sitio > Extensiones > Herramientas de accesibilidad**.

La actualización conserva las preferencias existentes y crea un índice único por usuario y widget, eliminando duplicados antiguos y conservando el registro más reciente.

## Nota tipográfica

La opción de lectura accesible utiliza una pila de fuentes locales (`Atkinson Hyperlegible`, `OpenDyslexic`, Arial) y no distribuye archivos de fuente.

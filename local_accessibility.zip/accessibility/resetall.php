<?php
// This file is part of Moodle - https://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

if (!data_submitted()) {
    throw new moodle_exception('invalidrequest', 'error');
}
require_sesskey();
$returnurl = optional_param('returnurl', new moodle_url('/'), PARAM_LOCALURL);
local_accessibility_resetalluserconfigs();
redirect($returnurl);

// This file is part of Moodle - https://moodle.org/

import {saveWidgetConfig} from './common';

export const init = (widget, savewidgetname, stylename, bodyclassname = undefined,
        selector = 'body, body *') => {
    const container = document.getElementById(`${widget}-container`);
    if (!container) {
        return;
    }
    const input = container.querySelector('input[name="color"]');
    const reset = container.querySelector(`.${widget}-resetbtn`);
    if (!input) {
        return;
    }

    const revokeDefault = () => {
        if (bodyclassname) {
            document.body.classList.remove(bodyclassname);
        }
    };
    const attr = `data-default-${stylename}`;

    const applyColour = async colour => {
        if (!/^#[0-9a-f]{6}$/i.test(colour)) {
            return;
        }
        revokeDefault();
        document.querySelectorAll(selector).forEach(element => {
            if (!element.hasAttribute(attr)) {
                element.setAttribute(attr, window.getComputedStyle(element).getPropertyValue(stylename) || '');
            }
            element.style.setProperty(stylename, colour);
        });
        await saveWidgetConfig(savewidgetname, colour);
    };

    input.addEventListener('change', () => applyColour(input.value));
    if (reset) {
        reset.addEventListener('click', async() => {
            revokeDefault();
            document.querySelectorAll(selector).forEach(element => {
                const original = element.getAttribute(attr) || '';
                if (original) {
                    element.style.setProperty(stylename, original);
                } else {
                    element.style.removeProperty(stylename);
                }
                element.removeAttribute(attr);
            });
            await saveWidgetConfig(savewidgetname, null);
        });
    }
};

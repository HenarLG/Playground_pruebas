// This file is part of Moodle - https://moodle.org/

/** Initialise a range-selector widget without writing its value during page load. */
export const initrangewidget = (name, callback, userdefault = undefined) => {
    const input = document.getElementById(`${name}-input`);
    const label = document.getElementById(`${name}-label`);
    const up = document.getElementById(`${name}-btnup`);
    const down = document.getElementById(`${name}-btndown`);
    const reset = document.getElementById(`${name}-btnreset`);
    if (!input) {
        return;
    }

    const min = Number.parseFloat(input.min);
    const max = Number.parseFloat(input.max);
    const step = Number.parseFloat(input.step);
    const defaultvalue = Number.parseFloat(input.dataset.default);
    const format = value => String(Number.parseFloat(Number(value).toFixed(3)));

    const updateDisplay = value => {
        const formatted = format(value);
        if (label) {
            label.value = formatted;
            label.textContent = formatted;
        }
        input.setAttribute('aria-valuenow', formatted);
    };

    const commit = () => {
        updateDisplay(input.value);
        if (callback) {
            callback(Number.parseFloat(input.value));
        }
    };

    input.addEventListener('input', () => updateDisplay(input.value));
    input.addEventListener('change', commit);
    if (up) {
        up.addEventListener('click', () => {
            input.value = String(Math.min(max, Number.parseFloat(input.value) + step));
            commit();
        });
    }
    if (down) {
        down.addEventListener('click', () => {
            input.value = String(Math.max(min, Number.parseFloat(input.value) - step));
            commit();
        });
    }
    if (reset) {
        reset.addEventListener('click', () => {
            input.value = String(defaultvalue);
            commit();
        });
    }

    if (userdefault !== undefined && userdefault !== null && userdefault !== '') {
        input.value = String(Math.min(max, Math.max(min, Number.parseFloat(userdefault))));
    }
    updateDisplay(input.value);
};

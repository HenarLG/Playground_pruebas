// This file is part of Moodle - https://moodle.org/

import {call} from 'core/ajax';

let storageKey = 'local_accessibility.cache.v3.guest';
let cache = {};
let confirmedCache = {};
const queues = new Map();
const revisions = new Map();

const readCache = () => {
    try {
        return JSON.parse(window.localStorage.getItem(storageKey) || '{}') || {};
    } catch (error) {
        return {};
    }
};

const writeCache = () => {
    try {
        window.localStorage.setItem(storageKey, JSON.stringify(cache));
    } catch (error) {
        // Storage may be unavailable. Server persistence remains authoritative.
    }
};

const normaliseCache = values => {
    const result = Object.assign({}, values);
    Object.keys(result).forEach(name => {
        if (result[name] === null || result[name] === '') {
            delete result[name];
        } else {
            result[name] = String(result[name]);
        }
    });
    return result;
};

export const initCache = (userkey, serverconfigs = {}) => {
    storageKey = `local_accessibility.cache.v3.${userkey}`;
    // The server is authoritative on every page load; localStorage is only the fast optimistic cache.
    confirmedCache = normaliseCache(serverconfigs);
    cache = Object.assign({}, confirmedCache);
    queues.clear();
    revisions.clear();
    writeCache();
};

export const getCachedWidgetConfig = widget => {
    if (!Object.keys(cache).length) {
        cache = normaliseCache(readCache());
        confirmedCache = Object.assign({}, cache);
    }
    return Object.prototype.hasOwnProperty.call(cache, widget) ? cache[widget] : null;
};

export const clearCache = () => {
    cache = {};
    confirmedCache = {};
    queues.clear();
    revisions.clear();
    try {
        window.localStorage.removeItem(storageKey);
    } catch (error) {
        // Ignore storage errors.
    }
};

const setCacheValue = (target, widget, configvalue) => {
    if (configvalue === null || configvalue === undefined || configvalue === '') {
        delete target[widget];
    } else {
        target[widget] = String(configvalue);
    }
};

/**
 * Persist a preference in request order. The server remains authoritative.
 *
 * @param {string} widget Widget name.
 * @param {string|number|null|undefined} configvalue Preference value.
 * @returns {Promise<object|false>} Service response, or false when persistence failed.
 */
export const saveWidgetConfig = async(widget, configvalue) => {
    const revision = (revisions.get(widget) || 0) + 1;
    revisions.set(widget, revision);
    setCacheValue(cache, widget, configvalue);
    writeCache();
    window.dispatchEvent(new CustomEvent('local_accessibility:save-start', {detail: {widget}}));

    const previous = queues.get(widget) || Promise.resolve();
    const request = previous.catch(() => null).then(async() => {
        const response = await call([{
            methodname: 'local_accessibility_savewidgetconfig',
            args: {widget, configvalue: configvalue ?? null}
        }])[0];
        setCacheValue(confirmedCache, widget, configvalue);
        return response;
    });
    queues.set(widget, request);

    try {
        const result = await request;
        window.dispatchEvent(new CustomEvent('local_accessibility:save-success', {detail: {widget}}));
        return result;
    } catch (error) {
        if (revisions.get(widget) === revision) {
            if (Object.prototype.hasOwnProperty.call(confirmedCache, widget)) {
                cache[widget] = confirmedCache[widget];
            } else {
                delete cache[widget];
            }
            writeCache();
        }
        window.dispatchEvent(new CustomEvent('local_accessibility:save-error', {detail: {widget, error}}));
        return false;
    } finally {
        if (queues.get(widget) === request) {
            queues.delete(widget);
        }
    }
};

// This file is part of Moodle - https://moodle.org/

import {clearCache} from './common';

const focusableSelector = [
    'a[href]', 'button:not([disabled])', 'input:not([disabled])', 'select:not([disabled])',
    'textarea:not([disabled])', '[tabindex]:not([tabindex="-1"])'
].join(',');

let initialised = false;
let initialisationPending = false;
let initialisationObserver = null;
let lastFocus = null;
let previousOverflow = '';
let backgroundState = [];
let pendingSaves = 0;

const visibleFocusable = container => [...container.querySelectorAll(focusableSelector)].filter(element =>
    !element.hidden && element.getAttribute('aria-hidden') !== 'true' && element.getClientRects().length > 0
);

const setBackgroundInert = (modal, enabled) => {
    if (enabled) {
        backgroundState = [...document.body.children]
            .filter(element => element !== modal && !element.contains(modal))
            .map(element => ({
                element,
                hadInert: element.hasAttribute('inert'),
                ariaHidden: element.getAttribute('aria-hidden')
            }));
        backgroundState.forEach(({element}) => {
            element.setAttribute('inert', '');
            element.setAttribute('aria-hidden', 'true');
        });
        return;
    }
    backgroundState.forEach(({element, hadInert, ariaHidden}) => {
        if (!hadInert) {
            element.removeAttribute('inert');
        }
        if (ariaHidden === null) {
            element.removeAttribute('aria-hidden');
        } else {
            element.setAttribute('aria-hidden', ariaHidden);
        }
    });
    backgroundState = [];
};

/**
 * Attach the panel handlers once its footer markup exists.
 *
 * Moodle themes may render the before-footer hook immediately before the AMD
 * queue is flushed. The markup is therefore looked up at attachment time and
 * initialisation is retried after DOMContentLoaded when necessary.
 *
 * @returns {boolean} Whether the panel was attached.
 */
const attach = () => {
    if (initialised) {
        return true;
    }

    const launcher = document.getElementById('local-accessibility-openbtn');
    const modal = document.getElementById('local-accessibility-modal');
    const dialog = document.getElementById('local-accessibility-dialog');
    const closeButton = document.getElementById('local-accessibility-closebtn');
    const resetAll = document.getElementById('local-accessibility-resetall');
    const status = document.getElementById('local-accessibility-status');

    if (!launcher || !modal || !dialog || !closeButton) {
        return false;
    }
    initialised = true;
    initialisationPending = false;
    if (initialisationObserver) {
        initialisationObserver.disconnect();
        initialisationObserver = null;
    }

    const setStatus = text => {
        if (!status) {
            return;
        }
        status.textContent = '';
        window.setTimeout(() => {
            status.textContent = text;
        }, 20);
    };

    const open = event => {
        if (event) {
            event.preventDefault();
        }
        lastFocus = document.activeElement;

        // Do not move hook output while Moodle/the theme is still composing the footer.
        // Moving it lazily here keeps the launcher listener stable and makes the modal
        // a top-level sibling before the background is made inert.
        if (modal.parentElement !== document.body) {
            document.body.appendChild(modal);
        }

        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        launcher.setAttribute('aria-expanded', 'true');
        previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        document.body.classList.add('local-accessibility-dialog-open');
        setBackgroundInert(modal, true);
        window.requestAnimationFrame(() => closeButton.focus());
    };

    const close = () => {
        if (modal.hidden) {
            return;
        }
        setBackgroundInert(modal, false);
        modal.setAttribute('aria-hidden', 'true');
        modal.hidden = true;
        launcher.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = previousOverflow;
        document.body.classList.remove('local-accessibility-dialog-open');
        const target = lastFocus && document.contains(lastFocus) ? lastFocus : launcher;
        window.requestAnimationFrame(() => target.focus());
    };

    launcher.addEventListener('click', open);
    closeButton.addEventListener('click', close);
    modal.addEventListener('mousedown', event => {
        if (event.target === modal) {
            close();
        }
    });

    document.addEventListener('focusin', event => {
        if (!modal.hidden && !dialog.contains(event.target)) {
            const focusables = visibleFocusable(dialog);
            (focusables[0] || dialog).focus();
        }
    });

    dialog.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
            event.preventDefault();
            close();
            return;
        }
        if (event.key !== 'Tab') {
            return;
        }
        const focusables = visibleFocusable(dialog);
        if (!focusables.length) {
            event.preventDefault();
            dialog.focus();
            return;
        }
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
        }
    });

    if (resetAll) {
        resetAll.addEventListener('click', event => {
            const message = resetAll.dataset.confirm || M.str.local_accessibility.resetallconfirm;
            if (!window.confirm(message)) {
                event.preventDefault();
                return;
            }
            clearCache();
        });
    }

    window.addEventListener('local_accessibility:save-start', () => {
        pendingSaves++;
        dialog.setAttribute('aria-busy', 'true');
        setStatus(M.str.local_accessibility.preferencesaving);
    });
    window.addEventListener('local_accessibility:save-success', () => {
        pendingSaves = Math.max(0, pendingSaves - 1);
        if (pendingSaves) {
            setStatus(M.str.local_accessibility.preferencesaving);
        } else {
            dialog.removeAttribute('aria-busy');
            setStatus(M.str.local_accessibility.preferencesaved);
        }
    });
    window.addEventListener('local_accessibility:save-error', () => {
        pendingSaves = Math.max(0, pendingSaves - 1);
        if (!pendingSaves) {
            dialog.removeAttribute('aria-busy');
        }
        setStatus(M.str.local_accessibility.preferenceerror);
    });

    return true;
};

export const init = () => {
    if (initialised || attach() || initialisationPending) {
        return;
    }
    initialisationPending = true;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attach, {once: true});
    }

    // Some themes insert their footer asynchronously. Observe only until the panel
    // is found; attach() disconnects the observer immediately after success.
    if (window.MutationObserver && document.documentElement) {
        initialisationObserver = new MutationObserver(() => attach());
        initialisationObserver.observe(document.documentElement, {childList: true, subtree: true});
    }

    // A zero-delay retry also covers themes which append their footer in the same
    // event-loop turn after the AMD call was queued.
    window.setTimeout(() => {
        if (!attach() && !initialisationObserver) {
            initialisationPending = false;
        }
    }, 0);
};

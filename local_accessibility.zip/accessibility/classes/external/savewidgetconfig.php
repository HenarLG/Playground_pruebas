<?php
// This file is part of Moodle - https://moodle.org/

namespace local_accessibility\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

/** Save one user accessibility preference. */
class savewidgetconfig extends \core_external\external_api {
    public static function execute_parameters(): \core_external\external_function_parameters {
        return new \core_external\external_function_parameters([
            'widget' => new \core_external\external_value(PARAM_ALPHANUMEXT, 'Widget name'),
            'configvalue' => new \core_external\external_value(PARAM_RAW_TRIMMED, 'Configuration value', VALUE_DEFAULT, null, NULL_ALLOWED),
        ]);
    }

    public static function execute_returns(): \core_external\external_single_structure {
        return new \core_external\external_single_structure([
            'success' => new \core_external\external_value(PARAM_BOOL, 'True on success'),
        ]);
    }

    public static function execute(string $widget, ?string $configvalue = null): array {
        require_once(__DIR__ . '/../../lib.php');
        $params = self::validate_parameters(self::execute_parameters(), compact('widget', 'configvalue'));
        self::validate_context(\context_system::instance());
        if (strlen((string)$params['configvalue']) > 255) {
            throw new \invalid_parameter_exception('Configuration value is too long.');
        }
        if (!in_array($params['widget'], local_accessibility_getenabledwidgetnames(), true)) {
            throw new \invalid_parameter_exception('Unknown or disabled accessibility widget.');
        }
        $widgetinstance = local_accessibility_getwidgetinstancebyname($params['widget']);
        $widgetinstance->setuserconfig($params['configvalue']);
        return ['success' => true];
    }
}

<?php
// This file is part of Moodle - https://moodle.org/

namespace local_accessibility\hooks\output;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../../lib.php');

/** Load styles, server preferences and widget modules before output. */
class before_http_headers {
    public static function callback(\core\hook\output\before_http_headers $hook): void {
        global $PAGE, $USER;
        $widgetinstances = local_accessibility_getwidgetinstances();
        if (!$widgetinstances) {
            return;
        }
        $PAGE->requires->css('/local/accessibility/styles.css');
        $PAGE->requires->css('/local/accessibility/styles.php');

        $configs = [];
        foreach ($widgetinstances as $widgetinstance) {
            $configs[$widgetinstance->getname()] = $widgetinstance->getuserconfig();
        }
        $cachekey = (isloggedin() && !isguestuser()) ? 'user-' . (int)$USER->id : 'guest';
        $PAGE->requires->js_call_amd('local_accessibility/common', 'initCache', [$cachekey, $configs]);

        foreach ($widgetinstances as $widgetinstance) {
            $widgetinstance->init();
        }
    }
}

<?php
// This file is part of Moodle - https://moodle.org/

namespace local_accessibility\hooks\output;

use moodle_url;

/** Add the dynamically configured accessibility dialog to the page. */
class before_footer_html_generation {
    public static function callback(\core\hook\output\before_footer_html_generation $hook): void {
        global $CFG, $OUTPUT, $PAGE;
        $widgetinstances = local_accessibility_getwidgetinstances();
        if (!$widgetinstances) {
            return;
        }

        $PAGE->requires->strings_for_js([
            'preferenceerror', 'preferencesaved', 'preferencesaving', 'resetallconfirm',
        ], 'local_accessibility');
        $PAGE->requires->js_call_amd('local_accessibility/panel', 'init');

        $widgets = [];
        foreach ($widgetinstances as $widgetinstance) {
            $widgets[] = [
                'name' => $widgetinstance->getname(),
                'title' => $widgetinstance->gettitle(),
                'content' => $widgetinstance->getcontent(),
                'hasicon' => file_exists($CFG->dirroot . '/local/accessibility/widgets/' .
                    $widgetinstance->getname() . '/pix/icon.svg'),
            ];
        }

        $mainbutton = $OUTPUT->render_from_template('local_accessibility/mainbutton', []);
        $panel = $OUTPUT->render_from_template('local_accessibility/panel', [
            'widgets' => $widgets,
            'resetallaction' => (new moodle_url('/local/accessibility/resetall.php'))->out(false),
            'returnurl' => $PAGE->url->out(false),
            'sesskey' => sesskey(),
        ]);
        $hook->add_html($mainbutton . $panel);
    }
}

<?php
// This file is part of Moodle - https://moodle.org/

namespace local_accessibility\widgets;

/** Base class for range selector widgets. */
abstract class rangewidget extends widgetbase {
    protected $min;
    protected $max;
    protected $step;
    protected $default;

    public function __construct($title, $name, $min, $max, $step, $default) {
        parent::__construct($title, $name);
        $this->min = $min;
        $this->max = $max;
        $this->step = $step;
        $this->default = $default;
    }


    /**
     * Validate and persist a range value.
     *
     * @param mixed $value Configuration value, or null to restore the default.
     * @return mixed Database API result.
     */
    public function setuserconfig($value) {
        if ($value === null || $value === '') {
            return parent::setuserconfig(null);
        }
        if (!is_numeric($value)) {
            throw new \invalid_parameter_exception('The range value must be numeric.');
        }
        $numericvalue = (float)$value;
        $min = (float)$this->min;
        $max = (float)$this->max;
        $step = (float)$this->step;
        if ($numericvalue < $min || $numericvalue > $max) {
            throw new \invalid_parameter_exception('The range value is outside the allowed bounds.');
        }
        $neareststep = $min + round(($numericvalue - $min) / $step) * $step;
        if (abs($neareststep - $numericvalue) > 0.00001) {
            throw new \invalid_parameter_exception('The range value does not match the allowed step.');
        }
        if (abs($numericvalue - (float)$this->default) < 0.00001) {
            return parent::setuserconfig(null);
        }
        return parent::setuserconfig((string)$numericvalue);
    }

    public function getcontent() {
        global $OUTPUT;
        $userconfig = $this->getuserconfig();
        $current = is_numeric($userconfig) ? (float)$userconfig : $this->default;
        $current = min((float)$this->max, max((float)$this->min, $current));
        return $OUTPUT->render_from_template('local_accessibility/widgets/range', [
            'title' => $this->title,
            'name' => $this->getfullname(),
            'min' => $this->min,
            'max' => $this->max,
            'step' => $this->step,
            'default' => $this->default,
            'current' => $current,
            'decreaselabel' => get_string('decrease', 'local_accessibility', $this->title),
            'increaselabel' => get_string('increase', 'local_accessibility', $this->title),
            'sliderlabel' => get_string('sliderlabel', 'local_accessibility', $this->title),
        ]);
    }
}

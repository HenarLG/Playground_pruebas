<?php
// This file is part of Moodle - https://moodle.org/

namespace local_accessibility\widgets;

/** Base class for colour picker widgets. */
abstract class colourwidget extends widgetbase {
    protected $class = 'col-12';

 /**
     * Default colour shown when the user has no saved preference.
     *
     * @return string
     */
    protected function getdefaultcolour(): string {
        return '#000000';
    }

    public function setuserconfig($value) {
        if ($value === null || $value === '') {
            return parent::setuserconfig(null);
        }

        if (!is_string($value) || !preg_match('/^#[0-9a-f]{6}$/i', $value)) {
            throw new \invalid_parameter_exception(
                'The colour must use #RRGGBB notation.'
            );
        }

        return parent::setuserconfig(strtolower($value));
    }

    public function getcontent() {
        global $OUTPUT;

        $value = $this->getuserconfig();

        if (!is_string($value) || !preg_match('/^#[0-9a-f]{6}$/i', $value)) {
            $value = $this->getdefaultcolour();
        }

        return $OUTPUT->render_from_template(
            'local_accessibility/widgets/colour',
            [
                'name' => $this->getfullname(),
                'value' => $value,
                'colourlabel' => get_string(
                    'colourlabel',
                    'local_accessibility',
                    $this->title
                ),
            ]
        );
    }
}
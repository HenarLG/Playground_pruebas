<?php
// This file is part of Moodle - https://moodle.org/

namespace local_accessibility\widgets;

use stdClass;

/** Base class for accessibility widgets. */
abstract class widgetbase {
    protected $title;
    protected $name;
    protected $class = 'col-12';

    protected function __construct($title, $name) {
        $this->title = $title;
        $this->name = $name;
    }

    public function getname() { return $this->name; }
    public function getfullname() { return 'accessibility_' . $this->name; }
    public function gettitle() { return $this->title; }
    public function getclass() { return $this->class; }
    public function init() { return; }

    protected function isauthenticateduser(): bool {
        return isloggedin() && !isguestuser();
    }

    protected function getguestconfig() {
        global $SESSION;
        if (empty($SESSION->local_accessibility->guestconfigs) ||
                !property_exists($SESSION->local_accessibility->guestconfigs, $this->name)) {
            return null;
        }
        return $SESSION->local_accessibility->guestconfigs->{$this->name};
    }

    protected function setguestconfig($value): void {
        global $SESSION;
        if (empty($SESSION->local_accessibility)) {
            $SESSION->local_accessibility = new stdClass();
        }
        if (empty($SESSION->local_accessibility->guestconfigs)) {
            $SESSION->local_accessibility->guestconfigs = new stdClass();
        }
        if ($value === null || $value === '') {
            unset($SESSION->local_accessibility->guestconfigs->{$this->name});
            return;
        }
        $SESSION->local_accessibility->guestconfigs->{$this->name} = (string)$value;
    }

    public function getuserconfig() {
        global $DB, $USER;
        if (!$this->isauthenticateduser()) {
            return $this->getguestconfig();
        }
        $record = $DB->get_record('local_accessibility_configs',
            ['widget' => $this->name, 'userid' => $USER->id], 'configvalue');
        return $record ? $record->configvalue : null;
    }

    public function setuserconfig($value) {
        global $DB, $USER;
        $value = ($value === null || $value === '') ? null : (string)$value;
        if (!$this->isauthenticateduser()) {
            $this->setguestconfig($value);
            return true;
        }
        $conditions = ['widget' => $this->name, 'userid' => $USER->id];
        if ($value === null) {
            return $DB->delete_records('local_accessibility_configs', $conditions);
        }
        $record = $DB->get_record('local_accessibility_configs', $conditions);
        if ($record) {
            $record->configvalue = $value;
            return $DB->update_record('local_accessibility_configs', $record);
        }
        return $DB->insert_record('local_accessibility_configs', (object)[
            'widget' => $this->name,
            'userid' => $USER->id,
            'configvalue' => $value,
        ]);
    }

    protected function addbodyclass($classname): void {
        global $PAGE;
        $PAGE->add_body_class($classname);
    }

    abstract public function getcontent();
}

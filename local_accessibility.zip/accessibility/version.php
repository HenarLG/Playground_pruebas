<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_accessibility';
$plugin->release = '3.0.2';
$plugin->version = 2026062002;
$plugin->requires = 2024100700; // Moodle 4.5 or later.
$plugin->supported = [405, 599];
$plugin->maturity = MATURITY_STABLE;

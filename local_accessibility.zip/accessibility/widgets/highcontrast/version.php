<?php
// This file is part of Moodle - https://moodle.org/
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'accessibility_highcontrast';
$plugin->release = '1.0.0';
$plugin->version = 2026062000;
$plugin->requires = 2024100700;
$plugin->maturity = MATURITY_STABLE;
$plugin->supported = [405, 599];

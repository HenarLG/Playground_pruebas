// This file is part of Moodle - https://moodle.org/
import {saveWidgetConfig} from 'local_accessibility/common';

export const init = data => {
    const container = document.getElementById('accessibility_highcontrast-container');
    if (!container) { return; }
    const button = container.querySelector('.btn-toggler');
    if (!button) { return; }
    let enabled = data === true || data === 1 || data === '1';
    const render = () => {
        document.body.classList.toggle('accessibility-highcontrast', enabled);
        document.documentElement.classList.toggle('accessibility-highcontrast', enabled);
        button.setAttribute('aria-pressed', enabled ? 'true' : 'false');
        button.textContent = enabled ? M.str.accessibility_highcontrast.disable : M.str.accessibility_highcontrast.enable;
    };
    render();
    button.addEventListener('click', async() => {
        enabled = !enabled;
        render();
        await saveWidgetConfig('highcontrast', enabled ? '1' : null);
    });
};

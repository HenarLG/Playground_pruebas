# High contrast

Provides a server-persisted high-contrast mode.

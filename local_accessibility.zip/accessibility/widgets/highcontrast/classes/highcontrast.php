<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * High-contrast accessibility widget.
 *
 * @package     accessibility_highcontrast
 * @copyright   2026
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace accessibility_highcontrast;

use local_accessibility\widgets\widgetbase;

/** High-contrast accessibility widget definition. */
class highcontrast extends widgetbase {
    /** Initialise the widget metadata. */
    public function __construct() {
        parent::__construct(get_string('pluginname', 'accessibility_highcontrast'), 'highcontrast');
    }

    /** Load the saved state before page output. */
    public function init() {
        global $PAGE;
        $value = $this->getuserconfig();
        if ($value === '1') {
            $this->addbodyclass('accessibility-highcontrast');
        }
        $PAGE->requires->strings_for_js(['enable', 'disable'], 'accessibility_highcontrast');
        $PAGE->requires->js_call_amd('accessibility_highcontrast/script', 'init', [$value]);
    }

    /**
     * Render the widget control.
     *
     * @return string Rendered HTML.
     */
    public function getcontent() {
        global $OUTPUT;
        return $OUTPUT->render_from_template('accessibility_highcontrast/default', [
            'enabled' => $this->getuserconfig() === '1',
        ]);
    }

    /**
     * Persist the binary state in a canonical form.
     *
     * @param mixed $value Configuration value.
     * @return mixed Database API result.
     */
    public function setuserconfig($value) {
        return parent::setuserconfig(empty($value) ? null : '1');
    }
}

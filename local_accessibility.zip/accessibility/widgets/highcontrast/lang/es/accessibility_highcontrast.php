<?php
defined('MOODLE_INTERNAL') || die();
$string['disable'] = 'Desactivar';
$string['enable'] = 'Activar';
$string['pluginname'] = 'Alto contraste';

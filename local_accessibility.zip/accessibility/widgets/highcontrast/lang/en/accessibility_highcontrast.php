<?php
defined('MOODLE_INTERNAL') || die();
$string['disable'] = 'Disable';
$string['enable'] = 'Enable';
$string['pluginname'] = 'High contrast';

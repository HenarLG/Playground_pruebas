<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Visibilidad de imágenes';
$string['hideimages'] = 'Ocultar imágenes';
$string['showimages'] = 'Mostrar imágenes';

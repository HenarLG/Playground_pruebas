<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Kerning de la fuente';
$string['turnoffkerning'] = 'Desactivar kerning';
$string['turnonkerning'] = 'Activar kerning';

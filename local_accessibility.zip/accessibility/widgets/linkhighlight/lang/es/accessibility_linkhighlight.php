<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Resaltado de enlaces';
$string['disabled'] = 'Desactivado';
$string['enabled'] = 'Activado';

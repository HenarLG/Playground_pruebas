<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Tipo de letra';
$string['serif'] = 'Serif';
$string['sansserif'] = 'Sans serif';
$string['dyslexic'] = 'Lectura accesible';

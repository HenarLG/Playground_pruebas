<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Tamaño de letra';

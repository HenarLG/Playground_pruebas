<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Alineación del texto';
$string['left'] = 'Izquierda';
$string['center'] = 'Centrada';
$string['right'] = 'Derecha';


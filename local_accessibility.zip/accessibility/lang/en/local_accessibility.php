<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['accessibilitywidgets'] = 'Accessibility tools';
$string['actiondisable'] = 'Disable {$a}';
$string['actionmovedown'] = 'Move {$a} down';
$string['actionmoveup'] = 'Move {$a} up';
$string['addwidget'] = 'Add tool';
$string['closepanel'] = 'Close accessibility tools';
$string['colourlabel'] = 'Choose a colour for {$a}';
$string['decrease'] = 'Decrease {$a}';
$string['increase'] = 'Increase {$a}';
$string['manageenabledwidgets'] = 'Manage enabled accessibility tools';
$string['openpanel'] = 'Open accessibility tools';
$string['paneldescription'] = 'Adjust the interface. Changes are saved automatically.';
$string['paneltitle'] = 'Accessibility tools';
$string['pluginname'] = 'Accessibility';
$string['preferenceerror'] = 'The preference could not be saved on the server. Please try again.';
$string['preferencesaved'] = 'Preference saved.';
$string['preferencesaving'] = 'Saving preference…';
$string['privacy:metadata:configs'] = 'A saved configuration for an accessibility tool';
$string['privacy:metadata:configs:configvalue'] = 'Saved configuration value';
$string['privacy:metadata:configs:userid'] = 'The user assigned to the configuration';
$string['privacy:metadata:configs:widget'] = 'Accessibility tool name';
$string['reset'] = 'Reset';
$string['resetall'] = 'Reset all';
$string['resetallconfirm'] = 'Reset all accessibility preferences?';
$string['sliderlabel'] = '{$a} control';
$string['subplugintype_accessibility'] = 'Accessibility tool';
$string['subplugintype_accessibility_plural'] = 'Accessibility tools';
$string['widget'] = 'Tool';

<?php
// This file is part of Moodle - https://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['accessibilitywidgets'] = 'Herramientas de accesibilidad';
$string['actiondisable'] = 'Desactivar {$a}';
$string['actionmovedown'] = 'Mover {$a} hacia abajo';
$string['actionmoveup'] = 'Mover {$a} hacia arriba';
$string['addwidget'] = 'Añadir herramienta';
$string['closepanel'] = 'Cerrar herramientas de accesibilidad';
$string['colourlabel'] = 'Elegir un color para {$a}';
$string['decrease'] = 'Reducir {$a}';
$string['increase'] = 'Aumentar {$a}';
$string['manageenabledwidgets'] = 'Gestionar herramientas de accesibilidad activadas';
$string['openpanel'] = 'Abrir herramientas de accesibilidad';
$string['paneldescription'] = 'Ajusta la interfaz. Los cambios se guardan automáticamente.';
$string['paneltitle'] = 'Herramientas de accesibilidad';
$string['pluginname'] = 'Accesibilidad';
$string['preferenceerror'] = 'No se pudo guardar la preferencia en el servidor. Vuelve a intentarlo.';
$string['preferencesaved'] = 'Preferencia guardada.';
$string['preferencesaving'] = 'Guardando preferencia…';
$string['privacy:metadata:configs'] = 'Configuración guardada de una herramienta de accesibilidad';
$string['privacy:metadata:configs:configvalue'] = 'Valor de configuración guardado';
$string['privacy:metadata:configs:userid'] = 'Usuario asignado a la configuración';
$string['privacy:metadata:configs:widget'] = 'Nombre de la herramienta de accesibilidad';
$string['reset'] = 'Reiniciar';
$string['resetall'] = 'Reiniciar todo';
$string['resetallconfirm'] = '¿Reiniciar todas las preferencias de accesibilidad?';
$string['sliderlabel'] = 'Control de {$a}';
$string['subplugintype_accessibility'] = 'Herramienta de accesibilidad';
$string['subplugintype_accessibility_plural'] = 'Herramientas de accesibilidad';
$string['widget'] = 'Herramienta';
